// src/app/api/admin/qd-dev/knowledge-writer/route.ts
// POST /api/admin/qd-dev/knowledge-writer
// Saves AI analysis to 8 BigQuery tables:
//   projects (+ total_loc, health_score, folder_structure)
//   schema_columns (SQL + MongoDB unified)
//   tasks (replaces security_issues — all 4 categories)
//   controller_methods, data_flows, devops_config
//   ai_agents (NEW), cron_jobs (NEW)
//
// ─── BigQuery DDL needed before first use ─────────────────────
// ALTER TABLE `for-ga4-bitquery-new.QDDev_Project.projects`
//   ADD COLUMN IF NOT EXISTS total_loc INT64,
//   ADD COLUMN IF NOT EXISTS health_score INT64,
//   ADD COLUMN IF NOT EXISTS folder_structure STRING;
//
// ALTER TABLE `for-ga4-bitquery-new.QDDev_Project.schema_columns`
//   ADD COLUMN IF NOT EXISTS doc_count INT64;
//
// CREATE TABLE `for-ga4-bitquery-new.QDDev_Project.tasks` (
//   task_id STRING NOT NULL, project_id STRING NOT NULL,
//   project_name STRING, category STRING, title STRING,
//   description STRING, business_impact STRING, file_path STRING,
//   fix_steps STRING, fix_code STRING, effort_minutes INT64,
//   severity STRING, owasp_category STRING, assigned_to STRING,
//   status STRING, generated_by STRING, generated_by_name STRING,
//   chat_context STRING, created_at TIMESTAMP, updated_at TIMESTAMP);
//
// CREATE TABLE `for-ga4-bitquery-new.QDDev_Project.ai_agents` (
//   agent_id STRING NOT NULL, project_id STRING, project_name STRING,
//   file_path STRING, agent_type STRING, provider STRING, model STRING,
//   purpose STRING, call_pattern STRING, max_tokens INT64,
//   has_system_prompt BOOL, has_tools BOOL, created_at TIMESTAMP);
//
// CREATE TABLE `for-ga4-bitquery-new.QDDev_Project.cron_jobs` (
//   cron_id STRING NOT NULL, project_id STRING, project_name STRING,
//   source STRING, schedule STRING, schedule_human STRING,
//   path STRING, description STRING, max_duration INT64, created_at TIMESTAMP);
// ──────────────────────────────────────────────────────────────

import { NextRequest, NextResponse } from 'next/server'
import { verifyAdminRequest } from '@/lib/adminAuth'
import { getBigQuery } from '@/lib/bigquery'
import { randomUUID } from 'crypto'

const BQ_PROJECT = 'for-ga4-bitquery-new'
const BQ_DATASET = 'QDDev_Project'
const T = (t: string) => `\`${BQ_PROJECT}.${BQ_DATASET}.${t}\``

const SENSITIVE = [
  'password','passwd','pwd','secret','token','api_key','apikey',
  'private_key','access_token','refresh_token','auth_key',
  'recovery_email','credit_card','card_number','cvv',
]

function isSensitiveCol(name: string): boolean {
  return SENSITIVE.some(s => name.toLowerCase().includes(s))
}

function detectTableType(name: string, isMongo = false): string {
  if (isMongo) return 'mongodb'
  const n = name.toLowerCase()
  if (n.startsWith('cm_'))         return 'bq_native'
  if (n.startsWith('tbl_'))        return 'datastream_synced'
  if (n.startsWith('newultimez_')) return 'datastream_synced'
  if (n.includes('_view'))         return 'view'
  return 'mysql'
}

function parseStructuredData(html: string | null) {
  const empty = { tasks:[], controller_methods:[], data_flows:[], devops_config:[], ai_agents:[], cron_jobs:[] }
  if (!html) return empty
  const start = html.indexOf('<!-- STRUCTURED_DATA')
  const end   = html.indexOf('STRUCTURED_DATA -->')
  if (start === -1 || end === -1) return empty
  try {
    const p = JSON.parse(html.substring(start + 20, end).trim())
    return {
      tasks:              Array.isArray(p.tasks)              ? p.tasks              : [],
      controller_methods: Array.isArray(p.controller_methods) ? p.controller_methods : [],
      data_flows:         Array.isArray(p.data_flows)         ? p.data_flows         : [],
      devops_config:      Array.isArray(p.devops_config)      ? p.devops_config      : [],
      ai_agents:          Array.isArray(p.ai_agents)          ? p.ai_agents          : [],
      cron_jobs:          Array.isArray(p.cron_jobs)          ? p.cron_jobs          : [],
    }
  } catch { return empty }
}

function calcHealthScore(tasks: Record<string,unknown>[]): number {
  const costs: Record<string,number> = { critical:15, high:8, medium:3, low:1 }
  const deduction = tasks
    .filter(t => t.category === 'security')
    .reduce((s, t) => s + (costs[String(t.severity||'medium')]||3), 0)
  return Math.max(0, Math.min(100, 100 - deduction))
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function upsertProject(bq: any, body: Record<string,unknown>, html: string|null, healthScore: number, now: Date): Promise<string> {
  const projectName = body.project_name as string
  const [existing] = await bq.query({ query: `SELECT project_id FROM ${T('projects')} WHERE project_name=@pn LIMIT 1`, params: { pn: projectName } })
  const projectId: string = (existing as {project_id:string}[]).length ? existing[0].project_id : randomUUID()
  let stack = body.tech_stack; if (Array.isArray(stack)) stack = JSON.stringify(stack)
  let team  = body.team;       if (Array.isArray(team))  team  = JSON.stringify(team)
  const row = {
    project_id:       projectId,
    project_name:     projectName.substring(0,200),
    project_type:     ((body.project_type as string)||'web_app').substring(0,50),
    environment:      ((body.environment  as string)||'production').substring(0,50),
    repo_url:         (body.repo_url as string)||null,
    live_url:         (body.live_url as string)||null,
    description:      ((body.description as string)||null)?.substring(0,2000),
    tech_stack:       typeof stack==='string' ? stack : '[]',
    team_members:     typeof team ==='string' ? team  : '[]',
    analysis_focus:   ((body.analysis_focus as string)||null)?.substring(0,1000),
    priority:         (body.priority as string)||null,
    depth:            (body.depth    as string)||null,
    report_html:      html ? html.substring(0,900000) : null,
    total_files:      Number(body.total_files)||0,
    total_tables:     Number(body.total_tables)||0,
    total_columns:    Number(body.total_columns)||0,
    total_loc:        Number(body.total_loc)||0,
    health_score:     healthScore,
    folder_structure: (body.folder_structure as string)||null,
    created_by:       ((body.analysed_by as string)||'admin').substring(0,100),
    last_analysed:    now,
    created_at:       now,
  }
  if ((existing as unknown[]).length) {
    await bq.query({ query: `UPDATE ${T('projects')} SET project_type=@project_type,environment=@environment,repo_url=@repo_url,live_url=@live_url,description=@description,tech_stack=@tech_stack,team_members=@team_members,analysis_focus=@analysis_focus,priority=@priority,depth=@depth,report_html=@report_html,total_files=@total_files,total_tables=@total_tables,total_columns=@total_columns,total_loc=@total_loc,health_score=@health_score,folder_structure=@folder_structure,created_by=@created_by,last_analysed=@last_analysed,created_at=@created_at WHERE project_id=@project_id`, params: row })
  } else {
    await bq.dataset(BQ_DATASET).table('projects').insert([row])
  }
  return projectId
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function replaceSchemaColumns(bq: any, projectId: string, projectName: string, sqlTables: Record<string,unknown>[], mongoCollections: Record<string,unknown>[], now: Date) {
  await bq.query({ query: `DELETE FROM ${T('schema_columns')} WHERE project_id=@pid`, params: { pid: projectId } })
  const rows: Record<string,unknown>[] = []
  for (const t of sqlTables) {
    const tn = String(t.name||t.table||''); const fields = Array.isArray(t.fields) ? t.fields as Record<string,unknown>[] : []; let ord = 1
    for (const f of fields) { const cn = String(f.name||''); rows.push({ column_id:randomUUID(), project_id:projectId, project_name:projectName, table_name:tn, column_name:cn, data_type:String(f.type||f.data_type||'').substring(0,100), is_nullable:f.nullable!==false, is_pk:f.key==='PRI'||f.is_pk===true, is_fk:f.key==='MUL'||f.is_fk===true, fk_references:(f.fk_references as string)||null, is_security_risk:isSensitiveCol(cn), risk_reason:isSensitiveCol(cn)?'Sensitive column name':null, table_type:detectTableType(tn,false), ordinal_position:ord++, dataset_name:null, doc_count:null, created_at:now }) }
  }
  for (const col of mongoCollections) {
    const cn_col = String(col.collection||col.name||''); const fields = Array.isArray(col.fields) ? col.fields as Record<string,unknown>[] : []; let ord = 1
    for (const f of fields) { const fn = String(f.name||''); rows.push({ column_id:randomUUID(), project_id:projectId, project_name:projectName, table_name:cn_col, column_name:fn, data_type:String(f.type||'').substring(0,100), is_nullable:true, is_pk:fn==='_id', is_fk:f.type==='ObjectId'&&fn!=='_id', fk_references:null, is_security_risk:isSensitiveCol(fn), risk_reason:isSensitiveCol(fn)?'Sensitive field name':null, table_type:'mongodb', ordinal_position:ord++, dataset_name:null, doc_count:Number(col.doc_count)||null, created_at:now }) }
  }
  if (rows.length) { const CHUNK=200; for (let i=0;i<rows.length;i+=CHUNK) await bq.dataset(BQ_DATASET).table('schema_columns').insert(rows.slice(i,i+CHUNK)) }
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function replaceTasks(bq: any, projectId: string, projectName: string, tasks: Record<string,unknown>[], now: Date) {
  await bq.query({ query: `DELETE FROM ${T('tasks')} WHERE project_id=@pid AND generated_by='claude'`, params: { pid: projectId } })
  const rows = tasks.slice(0,200).map(t => {
    const cat = String(t.category||'bug')
    return { task_id:randomUUID(), project_id:projectId, project_name:projectName, category:['security','bug','scalable','research'].includes(cat)?cat:'bug', title:String(t.title||'').substring(0,500), description:(String(t.description||'')||null)?.substring(0,2000), business_impact:(String(t.business_impact||'')||null)?.substring(0,1000), file_path:(String(t.file_path||'')||null)?.substring(0,500), fix_steps:Array.isArray(t.fix_steps)?JSON.stringify(t.fix_steps):null, fix_code:(String(t.fix_code||'')||null)?.substring(0,5000), effort_minutes:Number(t.effort_minutes)||null, severity:['critical','high','medium','low'].includes(String(t.severity||''))?String(t.severity):null, owasp_category:(String(t.owasp_category||'')||null)?.substring(0,100), assigned_to:String(t.assigned_to||'Developer').substring(0,100), status:'open', generated_by:'claude', generated_by_name:null, chat_context:null, created_at:now, updated_at:now }
  })
  if (rows.length) { const CHUNK=100; for (let i=0;i<rows.length;i+=CHUNK) await bq.dataset(BQ_DATASET).table('tasks').insert(rows.slice(i,i+CHUNK)) }
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function replaceControllerMethods(bq: any, projectName: string, methods: Record<string,unknown>[], now: Date) {
  await bq.query({ query: `DELETE FROM ${T('controller_methods')} WHERE project_name=@pn`, params: { pn: projectName } })
  const rows = methods.slice(0,200).map(m => ({ method_id:randomUUID(), project_name:projectName, file_path:String(m.file_path||'').substring(0,500), class_name:(String(m.class_name||'')||null)?.substring(0,200), method_name:String(m.method_name||'').substring(0,200), http_method:String(m.http_method||'GET').substring(0,10), auth_level:String(m.auth_level||'public').substring(0,50), auth_condition:(String(m.auth_condition||'')||null)?.substring(0,500), purpose:(String(m.purpose||'')||null)?.substring(0,1000), db_tables_read:(String(m.db_tables_read||'')||null)?.substring(0,500), db_tables_write:(String(m.db_tables_write||'')||null)?.substring(0,500), calls_notification:Boolean(m.calls_notification), notification_ids:null, uses_redis:Boolean(m.uses_redis), redis_keys:null, has_file_upload:Boolean(m.has_file_upload), is_ajax:Boolean(m.is_ajax), role:null, created_at:now }))
  if (rows.length) await bq.dataset(BQ_DATASET).table('controller_methods').insert(rows)
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function replaceDataFlows(bq: any, projectName: string, flows: Record<string,unknown>[], now: Date) {
  await bq.query({ query: `DELETE FROM ${T('data_flows')} WHERE project_name=@pn`, params: { pn: projectName } })
  const rows = flows.slice(0,500).map(s => ({ step_id:randomUUID(), project_name:projectName, flow_id:String(s.flow_id||'').substring(0,100), flow_name:String(s.flow_name||'').substring(0,200), step_number:Number(s.step_number)||1, step_actor:String(s.step_actor||'').substring(0,100), step_action:String(s.step_action||'').substring(0,500), step_function:(String(s.step_function||'')||null)?.substring(0,200), step_db_table:(String(s.step_db_table||'')||null)?.substring(0,200), step_db_operation:(String(s.step_db_operation||'')||null)?.substring(0,20), step_triggers_notification:Boolean(s.step_triggers_notification), step_triggers_cache_bust:Boolean(s.step_triggers_cache_bust), created_at:now }))
  if (rows.length) await bq.dataset(BQ_DATASET).table('data_flows').insert(rows)
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function replaceDevopsConfig(bq: any, projectName: string, devops: Record<string,unknown>[], now: Date) {
  await bq.query({ query: `DELETE FROM ${T('devops_config')} WHERE project_name=@pn`, params: { pn: projectName } })
  const rows = devops.slice(0,100).map(d => ({ config_id:randomUUID(), project_name:projectName, component:String(d.component||'').substring(0,200), failure_impact:(String(d.failure_impact||'')||null)?.substring(0,500), risk_level:['critical','high','medium','low'].includes(String(d.risk_level||''))?String(d.risk_level):'medium', mitigation:(String(d.mitigation||'')||null)?.substring(0,500), cache_key_pattern:(String(d.cache_key_pattern||'')||null)?.substring(0,200), env_var_name:(String(d.env_var_name||'')||null)?.substring(0,200), env_var_required_by:(String(d.env_var_required_by||'')||null)?.substring(0,200), env_var_sensitive:Boolean(d.env_var_sensitive), created_at:now }))
  if (rows.length) await bq.dataset(BQ_DATASET).table('devops_config').insert(rows)
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function replaceAiAgents(bq: any, projectId: string, projectName: string, agents: Record<string,unknown>[], now: Date) {
  await bq.query({ query: `DELETE FROM ${T('ai_agents')} WHERE project_id=@pid`, params: { pid: projectId } })
  const rows = agents.slice(0,50).map(a => ({ agent_id:randomUUID(), project_id:projectId, project_name:projectName, file_path:String(a.file_path||'').substring(0,500), agent_type:String(a.agent_type||'LLM Call').substring(0,100), provider:String(a.provider||'Unknown').substring(0,100), model:(String(a.model||'')||null)?.substring(0,200), purpose:(String(a.purpose||'')||null)?.substring(0,1000), call_pattern:String(a.call_pattern||'Single call').substring(0,100), max_tokens:Number(a.max_tokens)||null, has_system_prompt:Boolean(a.has_system_prompt), has_tools:Boolean(a.has_tools), created_at:now }))
  if (rows.length) await bq.dataset(BQ_DATASET).table('ai_agents').insert(rows)
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function replaceCronJobs(bq: any, projectId: string, projectName: string, crons: Record<string,unknown>[], now: Date) {
  await bq.query({ query: `DELETE FROM ${T('cron_jobs')} WHERE project_id=@pid`, params: { pid: projectId } })
  const rows = crons.slice(0,50).map(c => ({ cron_id:randomUUID(), project_id:projectId, project_name:projectName, source:String(c.source||'unknown').substring(0,100), schedule:String(c.schedule||'').substring(0,100), schedule_human:String(c.schedule_human||'').substring(0,200), path:(String(c.path||'')||null)?.substring(0,500), description:(String(c.description||'')||null)?.substring(0,1000), max_duration:Number(c.max_duration)||null, created_at:now }))
  if (rows.length) await bq.dataset(BQ_DATASET).table('cron_jobs').insert(rows)
}

export async function POST(req: NextRequest) {
  if (!await verifyAdminRequest(req))
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json().catch(() => ({})) as Record<string,unknown>
  const projectName = ((body.project_name as string)||'').trim()
  if (!projectName) return NextResponse.json({ error: 'project_name required' }, { status: 400 })

  const bq  = getBigQuery()
  const now = new Date()
  const html: string|null = typeof body.report_html==='string' ? (body.report_html as string).substring(0,900000) : null

  try {
    const structured = parseStructuredData(html)

    const tasks = (Array.isArray(body.tasks) && (body.tasks as unknown[]).length)
      ? body.tasks as Record<string,unknown>[]
      : structured.tasks

    const healthScore = calcHealthScore(tasks)
    const projectId   = await upsertProject(bq, body, html, healthScore, now)

    const sqlTables        = Array.isArray(body.tables)         ? body.tables         as Record<string,unknown>[] : []
    const mongoCollections = Array.isArray(body.mongodb_tables) ? body.mongodb_tables as Record<string,unknown>[] : []
    if (sqlTables.length || mongoCollections.length)
      await replaceSchemaColumns(bq, projectId, projectName, sqlTables, mongoCollections, now)

    if (tasks.length) await replaceTasks(bq, projectId, projectName, tasks, now)

    const methods = structured.controller_methods.length ? structured.controller_methods : (Array.isArray(body.controller_methods) ? body.controller_methods as Record<string,unknown>[] : [])
    if (methods.length) await replaceControllerMethods(bq, projectName, methods, now)

    const flows = structured.data_flows.length ? structured.data_flows : (Array.isArray(body.data_flows) ? body.data_flows as Record<string,unknown>[] : [])
    if (flows.length) await replaceDataFlows(bq, projectName, flows, now)

    const devops = structured.devops_config.length ? structured.devops_config : (Array.isArray(body.devops_config) ? body.devops_config as Record<string,unknown>[] : [])
    if (devops.length) await replaceDevopsConfig(bq, projectName, devops, now)

    const agents = structured.ai_agents.length ? structured.ai_agents : (Array.isArray(body.ai_agents) ? body.ai_agents as Record<string,unknown>[] : [])
    if (agents.length) await replaceAiAgents(bq, projectId, projectName, agents, now)

    const crons = structured.cron_jobs.length ? structured.cron_jobs : (Array.isArray(body.cron_jobs) ? body.cron_jobs as Record<string,unknown>[] : [])
    if (crons.length) await replaceCronJobs(bq, projectId, projectName, crons, now)

    return NextResponse.json({
      ok: true, project_id: projectId, health_score: healthScore,
      saved: {
        schema_columns:      sqlTables.reduce((n,t)=>n+((t.fields as unknown[])?.length||0),0)+mongoCollections.reduce((n,c)=>n+((c.fields as unknown[])?.length||0),0),
        mongodb_collections: mongoCollections.length,
        tasks:               tasks.length,
        controller_methods:  methods.length,
        data_flow_steps:     flows.length,
        devops_config:       devops.length,
        ai_agents:           agents.length,
        cron_jobs:           crons.length,
      },
    })

  } catch (err: unknown) {
    console.error('[knowledge-writer] ERROR:', err)
    const e = err as Record<string,unknown>
    return NextResponse.json({ ok:false, error: String((e?.message as string)||((e?.errors as Array<{message:string}>)?.[0]?.message)||JSON.stringify(err)) })
  }
}
